module.exports = {
    "env": {
        "mocha": true,
        "commonjs": true,
        "shared-node-browser": true
    },
    ...require('../../eslint.config.js')
}
