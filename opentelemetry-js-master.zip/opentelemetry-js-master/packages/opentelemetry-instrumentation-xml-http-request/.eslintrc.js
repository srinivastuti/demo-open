module.exports = {
    "env": {
        "mocha": true,
        "commonjs": true,
        "browser": true,
        "jquery": true
    },
    ...require('../../eslint.config.js')
}
