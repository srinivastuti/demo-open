Object.defineProperty(exports, "__esModule", { value: true });
exports.externallyExportedFunction = function externallyExportedFunction() {
  return true;
}
