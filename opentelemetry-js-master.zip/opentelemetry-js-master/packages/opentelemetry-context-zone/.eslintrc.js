module.exports = {
    "env": {
        "browser": true,
        "commonjs": true
    },
    ...require('../../eslint.config.js')
}
